﻿# FoodRescue AI - Frontend Platform
> **Tagline:** Predict Â· Rescue Â· Redistribute Â· Sustain  
> **Team:** TECH TITANS

Enterprise web application for B2B & institutional surplus food management.

## Package Contents

1. **Modern React 19 + Vite + Tailwind CSS v4** (src/, index.html, ite.config.js)
   - Reactive multi-role switcher (Overview, Food Donor, NGO Portal, Delivery Fleet, Command Center)
   - Real-time countdown urgency badges and dynamic 3-tier escalation engine
   - AI Vision volumetric gastronorm container scanner
   - FSSAI Digital Safety & Handover Gate with Dual-Key QR/OTP verification and Form-IX e-Handover slip
   - Hyperlocal 5 km NGO relief feed with portion calculators
   - Interactive route radar with Green Corridor traffic routing and EV fleet telematics
   - ESG analytics, Section 80G CSR tax certificate generator, and Institutional Leaderboard
2. **Pre-built Production Bundle** (dist/)
   - Fully compiled, optimized HTML/CSS/JS ready for instant deployment on Vercel, Netlify, Cloudflare Pages, AWS S3, or any static web server without requiring Node.js.
3. **Vanilla Single-Page Edition** (rontend/)
   - Zero-dependency HTML5 / CSS3 / ES6 vanilla edition.

## Quick Start (Development Server)

### Prerequisites
- Node.js (v18 or higher recommended)
- npm (v9 or higher)

### Installation & Run
1. Install dependencies:
   `ash
   npm install
   `
2. Start the local development server:
   `ash
   npm run dev
   `
   Open your browser at http://localhost:5173.

3. Or run via the included Windows launcher:
   Double-click un_frontend.bat.

## Production Build & Serve

`ash
# Build production bundle to /dist
npm run build

# Preview production build locally
npm run preview
`

Or serve the included dist/ directory directly with any static server:
`ash
npx serve dist -p 5000
`
