@echo off
echo ========================================================
echo  Starting FoodRescue AI Frontend (Vite Dev Server)
echo ========================================================
where npm >nul 2>nul
if %errorlevel% neq 0 (
    echo Error: npm is not found in PATH. Please install Node.js.
    pause
    exit /b
)
if not exist node_modules (
    echo Installing dependencies...
    call npm install
)
echo Launching dev server on http://localhost:5173 ...
call npm run dev -- --open
pause
