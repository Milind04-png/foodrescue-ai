﻿# FoodRescue AI - Backend API & AI Engine
> **Tagline:** Predict Â· Rescue Â· Redistribute Â· Sustain  
> **Team:** TECH TITANS

FastAPI Python server powering machine learning demand forecasting, FSSAI microbial shelf-life decay calculation, multi-criteria NGO matching, micro-logistics routing, and Section 80G compliance audit trail.

## Package Contents

- **ackend/main.py**: REST API server & route handlers with auto-fallback for standalone mode.
- **ackend/ml_engine.py**: Scikit-Learn demand forecaster & Arrhenius microbial shelf-life kinetics engine.
- **ackend/mock_data.py**: Enterprise seed data for institutional donors, verified NGOs, and EV fleet.
- **	ests/test_api.py**: Automated unit test suite verifying forecasting, shelf-life, and matching.
- **equirements.txt**: Python dependencies list.

## Quick Start

### Prerequisites
- Python 3.9+ installed
- pip package manager

### Installation & Run
1. Install dependencies:
   `ash
   pip install -r requirements.txt
   `
2. Launch the backend server:
   `ash
   python backend/main.py
   `
   Or using Uvicorn directly:
   `ash
   uvicorn backend.main:app --host 127.0.0.1 --port 8000 --reload
   `

3. Or run via the included Windows launcher:
   Double-click un_backend.bat.

### Interactive Documentation & Testing
- Interactive Swagger UI: http://127.0.0.1:8000/docs
- ReDoc API Reference: http://127.0.0.1:8000/redoc
- Run automated unit test suite:
  `ash
  python tests/test_api.py
  `

## Key API Endpoints
- GET /api/status: System status and engine health
- GET /api/data: Full dataset (donors, NGOs, fleet, donations, ESG metrics)
- POST /api/predict-demand: ML demand prediction based on day, weather, festival, planned portions
- POST /api/check-shelf-life: FSSAI microbial decay calculation based on ambient temp & preparation time
- POST /api/match: Proximity & capacity NGO recipient matching
- POST /api/donations: Create and list new bulk donation
- POST /api/claim: NGO claim allocation
- POST /api/certificate/generate: Section 80G CSR Tax Exemption & Sustainability Certificate
