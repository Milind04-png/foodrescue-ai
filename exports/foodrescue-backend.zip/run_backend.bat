@echo off
echo ========================================================
echo  Starting FoodRescue AI Backend Server (FastAPI)
echo ========================================================
where python >nul 2>nul
if %errorlevel% neq 0 (
    echo Error: python is not found in PATH. Please install Python 3.9+.
    pause
    exit /b
)
echo Installing / verifying dependencies...
call pip install -r requirements.txt
echo.
echo Launching FastAPI Server on http://127.0.0.1:8000 ...
echo Swagger UI docs available at: http://127.0.0.1:8000/docs
echo.
call python backend/main.py
pause
